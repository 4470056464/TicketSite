import os
if 'DJANGO_SETTINGS_MODULE' in os.environ:
    from .utils import *

__author__ = 'Incuna Ltd'
__version__ = '3.3.0'
